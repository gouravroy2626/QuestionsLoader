import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.html', // only contains <router-outlet>
  styleUrls: ['./app.css'],
  standalone:false
})
export class AppComponent {}
